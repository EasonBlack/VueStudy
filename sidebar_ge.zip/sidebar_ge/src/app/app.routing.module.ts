import { NgModule } from '@angular/core';
import { RouterModule, Route } from '@angular/router';
import { Sm11Component, Sm12Component, Sm21Component, Sm32Component, Sm51Component, Submenu11Component } from './component/index';

const routes: Route[]=[
  	{
    	path: "",
        redirectTo: "/11",
        pathMatch: "full"
    },
    /*{
        path: "11",
        component: Sm11Component
    },*/
    {
        path: "12",
        component: Sm12Component
    },
    {
        path: "21",
        component: Sm21Component
    },
    {
        path: "32",
        component: Sm32Component
    },
    {
        path: "51",
        component: Sm51Component
    },
    {
        path: "11",
        component: Submenu11Component
    }
]

@NgModule({
	imports: [
    	RouterModule.forRoot(routes, {useHash: true})
  	],
  	exports: [
  		RouterModule
  	]
})
export class AppRoutingModule { }