import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Url } from '../common/Url';

@Injectable()
export class HomeService {

  constructor(private http: HttpClient) { }

  getMarqueeData(): Observable<any> {
  	return this.http.get(Url.BaseUrl+Url.marqueeDataUrl);
  }
}
