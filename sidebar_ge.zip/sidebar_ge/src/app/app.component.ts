import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HomeService } from './service/home.service';

@Component({
	selector: 'app-root',
  	templateUrl: './app.component.html',
  	styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

	marqueeData= [];
  
  	constructor(private service: HomeService) {}

  	ngOnInit() {
      /*
        this.service.getMarqueeData().subscribe(response => {
            this.marqueeData=response;
            console.log(this.marqueeData);
        });	
        */
        this.marqueeData= [
            {
                value: 45.43,
                description: "PJM WEST HUB (LMP RT)"
            },
            {
                value: 50.30,
                description: "GRAYSFER 13 KV LOAD1 (LMP RT)"
            },
            {
                value: 51.25,
                description: "SWARK 13 KV NVYYRDBS (LMP RT)"
            },
            {
                value: 25.51,
                description: "RTO COMBINED (Regulation ASM)"
            }
        ]
  	}
}
