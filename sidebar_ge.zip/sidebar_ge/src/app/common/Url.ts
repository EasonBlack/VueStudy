export class Url {

	public static BaseUrl= "http://54.191.70.190:8082/ESCS/";

	public static marqueeDataUrl= "marquee/getMarqueeList";
}