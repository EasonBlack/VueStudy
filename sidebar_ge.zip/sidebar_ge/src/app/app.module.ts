import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AgmCoreModule } from '@agm/core'; 
import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';

import { AppComponent } from './app.component';
import { Sm11Component, Sm12Component, Sm21Component, Sm32Component, Sm51Component, Submenu11Component } from './component/index';
import { HomeService } from './service/home.service';
import { AppRoutingModule } from './app.routing.module';


@NgModule({
  declarations: [
    AppComponent,
    Sm11Component,
    Sm12Component,
    Sm21Component,
    Sm32Component,
    Sm51Component,
    Submenu11Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyCj-sUObPbqtkUZxltF3SJhrvhjajWkQas'
    }),
    MatDatepickerModule,
    MatNativeDateModule
  ],
  providers: [HomeService, MatNativeDateModule],
  bootstrap: [AppComponent]
})
export class AppModule { }
