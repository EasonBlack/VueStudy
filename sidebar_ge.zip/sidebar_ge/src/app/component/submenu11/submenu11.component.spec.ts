import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Submenu11Component } from './submenu11.component';

describe('Submenu11Component', () => {
  let component: Submenu11Component;
  let fixture: ComponentFixture<Submenu11Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Submenu11Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Submenu11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
