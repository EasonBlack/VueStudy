import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-submenu11',
  templateUrl: './submenu11.component.html',
  styleUrls: ['./submenu11.component.css']
})
export class Submenu11Component implements OnInit {

	content: string;
	constructor() { }

	lat= [39.893245, 39.888273, 39.896455, 39.888396];
	lng= [-75.174655, -75.185641, -75.173260, -75.177981];

	ngOnInit() {
	}

  	md(value: Node) {

  		this.content=value.textContent.trim();
  		console.log(this.content);
  	}
}
