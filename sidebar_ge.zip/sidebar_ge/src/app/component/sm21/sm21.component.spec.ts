import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Sm21Component } from './sm21.component';

describe('Sm21Component', () => {
  let component: Sm21Component;
  let fixture: ComponentFixture<Sm21Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Sm21Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Sm21Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
