import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sm21',
  templateUrl: './sm21.component.html',
  styleUrls: ['./sm21.component.css']
})
export class Sm21Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
