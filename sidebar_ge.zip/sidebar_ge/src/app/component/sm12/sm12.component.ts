import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sm12',
  templateUrl: './sm12.component.html',
  styleUrls: ['./sm12.component.css']
})
export class Sm12Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
