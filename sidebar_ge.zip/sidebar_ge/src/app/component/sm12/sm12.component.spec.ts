import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Sm12Component } from './sm12.component';

describe('Sm12Component', () => {
  let component: Sm12Component;
  let fixture: ComponentFixture<Sm12Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Sm12Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Sm12Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
