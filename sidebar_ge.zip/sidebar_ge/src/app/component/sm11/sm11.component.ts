import { Component, OnInit } from '@angular/core';

@Component({
  	selector: 'app-sm11',
  	templateUrl: './sm11.component.html',
  	styleUrls: ['./sm11.component.css']
})
export class Sm11Component implements OnInit {

	lat= [39.893245, 39.888273, 39.896455, 39.888396, 39.893278];
	lng= [-75.174655, -75.185641, -75.173260, -75.177981, -75.165235];

  	constructor() { }

  	ngOnInit() {
  	}

}
