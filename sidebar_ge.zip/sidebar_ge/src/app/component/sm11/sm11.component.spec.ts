import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Sm11Component } from './sm11.component';

describe('Sm11Component', () => {
  let component: Sm11Component;
  let fixture: ComponentFixture<Sm11Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Sm11Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Sm11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
