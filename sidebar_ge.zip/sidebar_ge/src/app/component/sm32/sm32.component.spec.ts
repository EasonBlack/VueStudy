import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Sm32Component } from './sm32.component';

describe('Sm32Component', () => {
  let component: Sm32Component;
  let fixture: ComponentFixture<Sm32Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Sm32Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Sm32Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
