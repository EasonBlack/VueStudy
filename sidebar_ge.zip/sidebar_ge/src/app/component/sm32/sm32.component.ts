import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sm32',
  templateUrl: './sm32.component.html',
  styleUrls: ['./sm32.component.css']
})
export class Sm32Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
