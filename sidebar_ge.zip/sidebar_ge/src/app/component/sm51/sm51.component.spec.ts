import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Sm51Component } from './sm51.component';

describe('Sm51Component', () => {
  let component: Sm51Component;
  let fixture: ComponentFixture<Sm51Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Sm51Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Sm51Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
