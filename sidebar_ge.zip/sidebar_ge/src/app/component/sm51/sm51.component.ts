import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sm51',
  templateUrl: './sm51.component.html',
  styleUrls: ['./sm51.component.css']
})
export class Sm51Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
